Team members:
Edwin Gong, egong6
Fahad Mohiuddin, fmohi2

Contribution:
While we have two separate files, we were working together to try and figure how to code the Fibonacci function. We had our own versions and we compared them to get closer to the
correct code.

How to run code:
replace the number for the input for the n you want


GitHub:
https://github.com/egong6/ECE366PROJTWO 